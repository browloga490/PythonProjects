Python 3.4.3 (v3.4.3:9b73f1c3e601, Feb 24 2015, 22:43:06) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> class className:
	def createName(self,name):
		self.name=name
	def displayName(self):
		return self.name
	def saying(self):
		print "hello %s" % self.name
		
SyntaxError: Missing parentheses in call to 'print'
>>> class className:
	def createName(self,name):
		self.name=name
	def displayName(self):
		return self.name
	def saying(self):
		print ("hello %s" % self.name)

		
>>> className
<class '__main__.className'>
>>> first=className()
>>> second=className()
>>> first.createName('Logan')
>>> second.creativeName('tony')
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    second.creativeName('tony')
AttributeError: 'className' object has no attribute 'creativeName'
>>> second.createName('tony')
>>> frist.displayName()
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    frist.displayName()
NameError: name 'frist' is not defined
>>> first.displayName()
'Logan'
>>> first.saying()
hello Logan
>>> 
