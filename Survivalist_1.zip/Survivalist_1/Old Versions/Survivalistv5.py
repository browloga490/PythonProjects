import pygame
import time
import random
import datetime

pygame.init()

display_width = 800
display_height = 600

gameDisplay = pygame.display.set_mode((display_width,display_height))


pygame.display.set_caption('Survivalist')

#icon = pygame.image.load('Apple.png')
#pygame.display.set_icon(icon)

colours = {"white": (255,255,255),
           "black": (0,0,0),
           "red": (200,0,0),
           "light_red": (255,0,0),
           "yellow": (200,200,0),
           "light_yellow": (255,255,0),
           "green": (0,155,0),
           "light_green": (0,255,0)
           }




clock = pygame.time.Clock()

smallfont = pygame.font.Font("Norefund.ttf", 20)
medfont = pygame.font.Font("Norefund.ttf", 50)
largefont = pygame.font.Font("Norefund.ttf", 65)

background = pygame.image.load('Background.png')
screen = pygame.image.load('Screen.png')
#img = pygame.image.load('SnakeHead.png')
#appleimg = pygame.image.load('Apple.png')




def score(score):
    
    text = smallfont.render("Score: "+str(score), True, colours["black"])
    gameDisplay.blit(text, [0, 0])
    

def text_objects(text, color, size):
    if size == "small":
        textSurface = smallfont.render(text, True, color)
    elif size == "medium":
        textSurface = medfont.render(text, True, color)
    elif size == "large":
        textSurface = largefont.render(text, True, color)
        
    return textSurface, textSurface.get_rect()

def text_to_button(msg, color, buttonx, buttony, buttonwidth, buttonheight, size = "small"):
    textSurf, textRect = text_objects(msg,color, size)
    textRect.center = ((buttonx+(buttonwidth/2)), buttony+(buttonheight/2))
    gameDisplay.blit(textSurf, textRect)
                       

def message_to_screen(msg,color, y_displace=0, size = "small"):
    textSurf, textRect = text_objects(msg,color, size)
    textRect.center = (display_width / 2), (display_height / 2)+y_displace
    gameDisplay.blit(textSurf, textRect)


def game_controls():
    
    gcont = True

    while gcont == True:

        for event in pygame.event.get():
            #print(event)
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        
        gameDisplay.fill(colours["white"])
        message_to_screen("Controls", colours["green"], -100, "large")
        message_to_screen("Fire: Spacebar", colours["black"], -30)
        message_to_screen("Move Turret: Up and Down arrows", colours["black"], 10)
        message_to_screen("Move Tank: Left and Right arrows", colours["black"], 50)
        message_to_screen("Pause: P", colours["black"], 90)


        button("play",150,500,100,50, colours["green"], colours["light_green"], action="play")
        button("Main",350,500,100,50, colours["yellow"], colours["light_yellow"], action="main")
        button("quit",550,500,100,50, colours["red"], colours["light_red"], action="quit")


        
        pygame.display.update()

        clock.tick(15)


def button(text, x, y, width, height, inactive_color, active_color, action = None):
    cur = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    #print(click)
    if x + width > cur[0] > x and y + height > cur[1] > y:
        pygame.draw.rect(gameDisplay, active_color, (x,y,width,height))
        if click[0] == 1 and action != None:
            if action == "quit":
                pygame.quit()
                quit()
                
            if action == "controls":
                game_controls()

            if action == "play":
                gameLoop()
                

            if action == "main":
                game_intro()
            
    else:
        pygame.draw.rect(gameDisplay, inactive_color, (x,y,width,height))

    text_to_button(text,colours["black"],x,y,width,height)


def pause():

    paused = True
    message_to_screen("Paused", colours["black"], -100, size="large")
    message_to_screen("Press C to continue or Q to quit.", colours["black"], 25)
    pygame.display.update()
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    paused = False

            elif event.key == pygame.K_q:
                pygame.quit()
                quit()



        clock.tick(5)

def game_intro():

    intro = True
    
    while intro == True:
        for event in pygame.event.get():
            #print(event)
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    intro = False
                elif event.key == pygame.K_q:

                    pygame.quit()
                    quit()
        
        gameDisplay.fill(colours["white"])
        gameDisplay.blit(background,(0,0))
        pygame.draw.rect(gameDisplay, colours["black"], ((display_width/2 - 275),100,550,350))
        gameDisplay.blit(screen,((display_width/2 - 275),100) )

        message_to_screen("Welcome to,",colours["black"],-100,"medium")
        message_to_screen("Survivalist", colours["green"], -30, "large")

        button("run",150,500,100,50, colours["green"], colours["light_green"], action="play")
        button("controls",350,500,100,50, colours["yellow"], colours["light_yellow"], action="controls")
        button("quit",550,500,100,50, colours["red"], colours["light_red"], action="quit")


        
        pygame.display.update()

        clock.tick(15)

def import_module():
    module = ["S1","S2","S3"]
    random.shuffle(module)
    pick = module[0]
    
    if pick == "S1":
        import S1
        S1.S1(message_to_screen,colours,gameDisplay,100,100,50,50,display_width)
        module.remove("S1")
    elif pick == "S2":
        import S2
        S2.S2(message_to_screen,colours,gameDisplay,100,100,50,50,display_width)
        module.remove("S2")
    elif pick == "S3":
        import S3
        S3.S3(message_to_screen,colours,gameDisplay,100,100,50,50,display_width)
        module.remove("S3")
        
        
def timer():
    dt = datetime.datetime.now()
    dt_HM = (dt.hour, dt.minute)

    if dt_HM == (1, 0):
        print ("Yes")
    elif dt_HM == (2, 0):
        print ("Yes")
    elif dt_HM == (3, 0):
        print ("Yes")
    elif dt_HM == (4, 0):
        print ("Yes")
    elif dt_HM == (5, 0):
        print ("Yes")
    elif dt_HM == (6, 0):
        print ("Yes")
    elif dt_HM == (7, 0):
        print ("Yes")
    elif dt_HM == (8, 0):
        print ("Yes")
    elif dt_HM == (9, 0):
        print ("Yes")
    elif dt_HM == (10, 0):
        print ("Yes")
    elif dt_HM == (11, 0):
        print ("Yes")
    elif dt_HM == (12, 0):
        print ("Yes")
    elif dt_HM == (13, 0):
        print ("Yes")
    elif dt_HM == (14, 0):
        print ("Yes")
    elif dt_HM == (15, 0):
        print ("Yes")
    elif dt_HM == (16, 0):
        print ("Yes")
    elif dt_HM == (17, 0):
        print ("Yes")
    elif dt_HM == (18, 0):
        print ("Yes")
    elif dt_HM == (19, 0):
        print ("Yes")
    elif dt_HM == (20, 0):
        print ("Yes")
    elif dt_HM == (21, 0):
        print ("Yes")
    elif dt_HM == (22, 0):
        print ("Yes")
    elif dt_HM == (23, 0):
        print ("Yes")
    elif dt_HM == (24, 0):
        print ("Yes")
    else:
        print ("No")

def gameLoop():
    gameExit = False
    gameOver = False
    FPS = 100



    

    while not gameExit:
        

        if gameOver == True:
            gameDisplay.fill(colours["white"])
            message_to_screen("Game over",colours["red"],y_displace=-50,size="large")
            message_to_screen("Press C to play again or Q to quit",colours["black"],50,size="medium")
            pygame.display.update()
            while gameOver == True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        gameOver = False
                        gameExit = True

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_c:
                            gameLoop()
                        elif event.key == pygame.K_q:

                            gameExit = True
                            gameOver = False
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    tankMove = -5
                    
                
                elif event.key == pygame.K_RIGHT:
                    pass
                    
                elif event.key == pygame.K_UP:
                    pass
                    
                elif event.key == pygame.K_DOWN:
                    pass

                elif event.key == pygame.K_p:
                    pass

                elif event.key == pygame.K_SPACE:
                    pass 

                elif event.key == pygame.K_a:
                    pass

                elif event.key == pygame.K_d:
                    pass

            elif event.type == pygame.KEYUP:

                if event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    pass

                if event.key == pygame.K_a or event.key == pygame.K_d:
                    pass

        
        gameDisplay.fill(colours["white"])
        import_module()
        timer()
        pygame.display.update()
        clock.tick(FPS)

    pygame.quit()
    quit()

game_intro()
gameLoop()



