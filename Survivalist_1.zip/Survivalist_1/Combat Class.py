import pygame
import time
import random

class player:
    def __init__(self):
        self.hp = 100
        self.hpMax = 100
        self.defense = 10
        self.attack = 5
    def hit(self, hp):
        self.hp -= hp
    def heal(self, hp):
        self.hp += hp
    def lvlUp(self, level):
        self.defense += level
        self.hpMax += 20
