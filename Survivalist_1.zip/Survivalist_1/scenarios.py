import pygame
import time
import random

clock = pygame.time.Clock()


def S1(message_to_screen,colours,gameDisplay,x,y,width,height):
        print("Hello World")
        message_to_screen("Testing S1.", colours["green"], -100, "large")
        pygame.draw.rect(gameDisplay, colours["black"], (x,y,width,height))
        pygame.display.update()
        clock.tick(1)
        

def S2(message_to_screen,colours,gameDisplay,x,y,width,height):
        print("Goodbye World")
        message_to_screen("Testing S2.", colours["yellow"], -25, "large")
        pygame.draw.rect(gameDisplay, colours["black"], (x,y,width,height))
        pygame.display.update()
        clock.tick(1)
        

def S3(message_to_screen,colours,gameDisplay,x,y,width,height):
        print("-___-")
        message_to_screen("Testing S3.", colours["red"], -50, "large")
        pygame.draw.rect(gameDisplay, colours["black"], (x,y,width,height))
        pygame.display.update()
        clock.tick(1)

def choices(message_to_screen,colours,gameDisplay):
        S1t = S1(message_to_screen,colours,gameDisplay,100,50,30,30)
        S2t = S2(message_to_screen,colours,gameDisplay,100,50,30,30)
        S3t = S3(message_to_screen,colours,gameDisplay,100,50,30,30)

        situation = [S1t,S2t,S3t]

        randChoice = random.choice(situation)
        randChoice

if __name__ == '__main__':
        S1(message_to_screen,colours,gameDisplay,x,y,width,height)
        S2(message_to_screen,colours,gameDisplay,x,y,width,height)
        S3(message_to_screen,colours,gameDisplay,x,y,width,height)

pass
