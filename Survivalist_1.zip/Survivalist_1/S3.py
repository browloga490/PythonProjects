import pygame
import time
import random

clock = pygame.time.Clock()

background = pygame.image.load('Background.png')
screen = pygame.image.load('Screen.png')

def S3(message_to_screen,colours,gameDisplay,x,y,width,height,display_width):
        gameDisplay.fill(colours["white"])
        gameDisplay.blit(background,(0,0))
        pygame.draw.rect(gameDisplay, colours["black"], ((display_width/2 - 275),100,550,350))
        gameDisplay.blit(screen,((display_width/2 - 275),100) )

        print("-___-")
        message_to_screen("Testing S3.", colours["red"], -50, "large")
        pygame.display.update()
        clock.tick(1)
