import pygame
import time
import random

clock = pygame.time.Clock()

background = pygame.image.load('Background.png')
screen = pygame.image.load('Screen.png')

def S2(message_to_screen,colours,gameDisplay,x,y,width,height,display_width):
        gameDisplay.fill(colours["white"])
        gameDisplay.blit(background,(0,0))
        pygame.draw.rect(gameDisplay, colours["black"], ((display_width/2 - 275),100,550,350))
        gameDisplay.blit(screen,((display_width/2 - 275),100) )

        print("Goodbye World")
        message_to_screen("Testing S2.", colours["yellow"], -25, "large")
        pygame.display.update()
        clock.tick(1)
