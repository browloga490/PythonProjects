import pygame
import time
import random

pygame.init()

display_width = 800
display_height = 600

gameDisplay = pygame.display.set_mode((display_width,display_height))


pygame.display.set_caption('Combat')

#icon = pygame.image.load('Apple.png')
#pygame.display.set_icon(icon)

colours = {"white": (255,255,255),
           "black": (0,0,0),
           "red": (200,0,0),
           "light_red": (255,0,0),
           "yellow": (200,200,0),
           "light_yellow": (255,255,0),
           "green": (0,155,0),
           "light_green": (0,255,0)
           }

clock = pygame.time.Clock()

smallfont = pygame.font.Font("Norefund.ttf", 20)
medfont = pygame.font.Font("Norefund.ttf", 50)
largefont = pygame.font.Font("Norefund.ttf", 65)

living_1  = True
HP1 = 100
DEF1 = 0
ATK1 = 3

living_2 = True
HP2 = 100
DEF2 = 0
ATK2 = 3

def player_1(living_1,HP1,DEF1,ATK1):
    
    if HP1 == 0:
        living == False
        print("DEAD")

def player_2():
    
    if HP2 == 0:
        living == False
        print("DEAD")

def attack(ATK):
    target = input("TARGET: ")
    if target == player_2:
        player


def gameLoop():
    gameExit = False
    gameOver = False
    FPS = 100

    while not gameExit:
        

        if gameOver == True:
            gameDisplay.fill(colours["white"])
            message_to_screen("Game over",colours["red"],y_displace=-50,size="large")
            message_to_screen("Press C to play again or Q to quit",colours["black"],50,size="medium")
            pygame.display.update()
            while gameOver == True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        gameOver = False
                        gameExit = True

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_c:
                            gameLoop()
                        elif event.key == pygame.K_q:

                            gameExit = True
                            gameOver = False
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True
        gameDisplay.fill(colours["white"])
        pygame.display.update()
        clock.tick(FPS)

    pygame.quit()
    quit()

gameLoop()
