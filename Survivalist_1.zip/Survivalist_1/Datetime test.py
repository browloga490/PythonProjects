import pygame
import time
import random
import datetime

dt = datetime.datetime.now()

if dt.hour == 19:
    print ("Yes")
    #import Survivalistv4

else:
    print("No")

dt_Hour_Minute = (dt.hour, dt.minute)

print (dt_Hour_Minute)
